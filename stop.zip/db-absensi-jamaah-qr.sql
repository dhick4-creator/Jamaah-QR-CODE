-- SQL script to create the database schema for Jamaah QR Code Attendance System

-- Table: profil_sekolah
CREATE TABLE IF NOT EXISTS profil_sekolah (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_sekolah VARCHAR(255) NOT NULL,
    logo VARCHAR(255) DEFAULT 'default.png'
);

-- Table: users
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    nama VARCHAR(100) NOT NULL,
    password VARCHAR(100) NOT NULL,
    role ENUM('admin', 'siswa', 'guru') DEFAULT 'siswa'
);

-- Table: siswa
CREATE TABLE IF NOT EXISTS siswa (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nis VARCHAR(10) NOT NULL,
    nisn VARCHAR(10) NOT NULL UNIQUE,
    nama VARCHAR(255) NOT NULL,
    kelas VARCHAR(10) NOT NULL,
    status ENUM('aktif', 'keluar') DEFAULT 'aktif'
);

-- Additional tables can be added here as needed for attendance, logs, etc.
