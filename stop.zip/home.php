<?php
// Redirect otomatis ke index.php jika file ini diakses langsung
header('Location: index.php');
exit;
